﻿// Corrected by Katon Bingham
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Lydia's code - find the errors!
namespace W5Exercise9
{
    class Set
    {
        private List<int> elements;


        public Set()
        {
            elements = new List<int>();
        }

        /* If contains element already, don't add.
         * else add. 
         */
        public bool addElement(int val)
        {
            if (containsElement(val)) return false;
            else
            {
                elements.Add(val);
                return true;
            }
        }

        private bool containsElement(int val)
        {
            // i++ is unreachable - is loop even necessary?
            for (int i = 0; i < elements.Count; i++)
            {
                if (val == elements[i])
                {
                    return true;
                }

                else
                {
                    return false;
                }
            }
            return false;
        }

        public override string ToString()
        {
            string str = "";
            foreach (int i in elements)
            {
                str += i + " ";
            }
            return str;
        }

        // non-issue
        public void clearSet()
        {
            elements.Clear();
        }

        // Rewriting this method to correctly execute the Union method
        // and return a NEW set, rather than editing the rhs data.
     // public Set union(Set rhs)
        public Set union(Set lhs, Set rhs)
        {
            /* adding elements to A, not a new Set.
             * New method body written below.
            for (int i = 0; i < rhs.elements.Count; i++)
            {
                this.addElement(rhs.elements[i]);
            }
            return rhs;
            */

            // Store union result
            Set AuB = new Set();
            
            // convert contents to list to use List.Union method 
            // no reason to reinvent the wheel
            List<int> listL = lhs.elements.ToList();
            List<int> listR = rhs.elements.ToList();

            // perform union operation, add result to Set class
            IEnumerable<int> union = listL.Union(listR);
            AuB.elements.AddRange(union);

            // return union operation in Set format
            return AuB;
        }
        
    }
}
