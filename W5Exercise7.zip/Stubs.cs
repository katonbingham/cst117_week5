﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W5Exercise7
{
    class Stubs
    {
        // 1
        public void add(int x, int y) { }
        // 2
        public double avgDouble(double a, double b, double c, double d, double e) { }
        // 3
        public int sum(int x, int y) { }
        // 4
        public bool isDivisibleby3(int x, int y, int z) { }
        // 5
        public void fewerChar(string a, string b) { }
        // 6
        public double largestValue(double[] x) { }
        // 7
        public double[] newArray() { }
        // 8
        public bool bothTrue(bool a, bool b) { }
        // 9
        public double sumOfIntPlusDouble(int x, double y) { }
        // 10
        public int avgOfArray(int[][] x) { }
    }
}
