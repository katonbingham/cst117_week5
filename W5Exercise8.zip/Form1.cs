﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W5Exercise8
{
    public partial class Form1 : Form
    {
        public double fatCalories(string a)
        {
            // convert input string to text
            double x = Convert.ToDouble(a);
            
            // do math
            x = x * 9;
            
            // return result
            return x;
        }

        public double carbCalories(string b)
        {
            // convert input string to text
            double x = Convert.ToDouble(b);
            
            // do math
            x = x * 4;

            //return result
            return x;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // convert and display
            string garbage = Convert.ToString(fatCalories(fatGramsInput.Text));
            fatResultLabel.Text = garbage;

            // convert and display
            garbage = Convert.ToString(carbCalories(carbsGramsInput.Text));
            carbsResultLabel.Text = garbage;
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
